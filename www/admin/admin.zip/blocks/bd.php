<?php
$db= mysql_connect("localhost","php","12345"); 
mysql_select_db("my_site",$db);

?>