﻿ <td width="251" height="430" valign="top" class="left">
 <p align="center" class="title"><a href="http://syte">На главную</a></p>
<p align="center" class="title">Уроки</p>
<div id="coolmenu">
<a href="new_lesson.php">Добавить урок</a>
<a href="edit_lesson.php">Редактировать урок</a>
<a href="del_lesson.php">Удалить урок</a>
</div>	

<p align="center" class="title">Статьи</p>
<div id="coolmenu">
<a href="new_articles.php">Добавить статью</a>
<a href="edit_articles.php">Редактировать статью</a>
<a href="del_articles.php">Удалить статью</a>
</div>	



<p align="center" class="title">Тексты</p>
<div id="coolmenu">
<a href="edit_text.php">Редактировать текст</a>
</div>	
</td>

