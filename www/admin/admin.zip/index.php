<?php ob_start();include ("lock.php");?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title> Главная страница админа</title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="900" height="489" border="0px" align="center" cellpadding="0" cellspacing="0" class="main_border" bgcolor="#FFFFFF">
  <?php include("blocks/header.php"); ?>
  <?php include("blocks/left.php"); ?>
  <td width="649" align="center" valign="top" class="main_border">
    <p>Добро пожаловать в админский блок!</p>
    <p>&nbsp;</p>
    <p>
    </td>
  </tr> 
<?php include("blocks/down.php"); ?>
</table>
</body>
</html>